import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import Layout from '@/components/Layout';
import Homepage from '@/pages/Homepage';
import Dashboard from '@/pages/Dashboard';
import Documentation from '@/pages/Documentation';
import { OnboardingProvider } from '@/contexts/OnboardingContext';
import './App.css';

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <OnboardingProvider>
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<Homepage />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/docs" element={<Documentation />} />
            </Routes>
          </Layout>
          <Toaster />
        </Router>
      </OnboardingProvider>
    </ThemeProvider>
  );
}

export default App;
