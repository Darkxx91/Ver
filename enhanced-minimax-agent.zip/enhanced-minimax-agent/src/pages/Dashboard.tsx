import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3,
  Brain,
  Clock,
  Star,
  TrendingUp,
  Users,
  Zap,
  Calendar,
  Activity,
  Target,
  BookmarkPlus,
  Settings,
  Download,
  Play,
  ChevronRight,
  Lightbulb,
  AlertCircle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Dashboard: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('week');

  const stats = {
    totalProjects: 47,
    activeWorkflows: 12,
    hoursSpent: 156,
    agentInteractions: 3847,
    efficiencyGain: 340,
    favoriteProjects: 23,
  };

  const recentProjects = [
    {
      id: '1',
      title: 'Market Research Report',
      type: 'Multi-Agent Swarm',
      status: 'completed',
      createdAt: '2 hours ago',
      duration: '45 min',
      efficiency: 85,
    },
    {
      id: '2',
      title: 'Website Redesign',
      type: 'Cross-Modal Pipeline',
      status: 'in-progress',
      createdAt: '1 day ago',
      duration: '2h 15m',
      efficiency: 92,
    },
    {
      id: '3',
      title: 'Financial Analysis',
      type: 'Reasoning Chain',
      status: 'completed',
      createdAt: '2 days ago',
      duration: '1h 30m',
      efficiency: 78,
    },
  ];

  const agentMemory = [
    {
      type: 'Preference',
      description: 'Prefers detailed technical documentation',
      confidence: 95,
      learned: '5 days ago',
    },
    {
      type: 'Pattern',
      description: 'Usually works on research projects in the morning',
      confidence: 87,
      learned: '1 week ago',
    },
    {
      type: 'Style',
      description: 'Likes concise executive summaries',
      confidence: 92,
      learned: '3 days ago',
    },
  ];

  const upcomingTasks = [
    {
      id: '1',
      title: 'Quarterly Business Review',
      description: 'Automated data collection and analysis',
      scheduledFor: 'Tomorrow 9:00 AM',
      estimatedDuration: '2 hours',
      agentType: 'Research Swarm',
    },
    {
      id: '2',
      title: 'Weekly Newsletter Generation',
      description: 'Content aggregation and formatting',
      scheduledFor: 'Friday 2:00 PM',
      estimatedDuration: '30 minutes',
      agentType: 'Content Agent',
    },
  ];

  const insights = [
    {
      type: 'efficiency',
      title: 'Productivity Peak',
      description: 'Your most productive time is 9-11 AM with multi-agent workflows',
      action: 'Schedule complex tasks during this window',
    },
    {
      type: 'pattern',
      title: 'Cross-Modal Usage',
      description: 'You use cross-modal features 3x more than average users',
      action: 'Consider exploring advanced multimodal templates',
    },
    {
      type: 'recommendation',
      title: 'Agent Swarm Opportunity',
      description: 'Research tasks could be 40% faster with swarm intelligence',
      action: 'Try swarm mode for your next research project',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-muted/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2">Welcome back, John!</h1>
                <p className="text-muted-foreground">
                  Your AI agents have been busy. Here's what they've learned and accomplished.
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <Button variant="outline">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
                <Button>
                  <Play className="h-4 w-4 mr-2" />
                  New Project
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8"
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Projects</p>
                  <p className="text-2xl font-bold">{stats.totalProjects}</p>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Workflows</p>
                  <p className="text-2xl font-bold">{stats.activeWorkflows}</p>
                </div>
                <Activity className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Hours Saved</p>
                  <p className="text-2xl font-bold">{stats.hoursSpent}</p>
                </div>
                <Clock className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">AI Interactions</p>
                  <p className="text-2xl font-bold">{stats.agentInteractions.toLocaleString()}</p>
                </div>
                <Brain className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Efficiency Gain</p>
                  <p className="text-2xl font-bold">{stats.efficiencyGain}%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Saved Projects</p>
                  <p className="text-2xl font-bold">{stats.favoriteProjects}</p>
                </div>
                <Star className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Recent Projects */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Recent Projects</span>
                    <Button variant="outline" size="sm">
                      View All
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentProjects.map((project) => (
                      <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-medium">{project.title}</h4>
                            <Badge variant={project.status === 'completed' ? 'default' : 'secondary'}>
                              {project.status}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span>{project.type}</span>
                            <span>•</span>
                            <span>{project.createdAt}</span>
                            <span>•</span>
                            <span>{project.duration}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <div className="text-sm font-medium">{project.efficiency}% efficient</div>
                            <Progress value={project.efficiency} className="w-20 h-2" />
                          </div>
                          <Button variant="ghost" size="sm">
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Agent Memory Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="h-5 w-5 mr-2" />
                    Agent Memory & Learning
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    What your AI agents have learned about your work patterns
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {agentMemory.map((memory, index) => (
                      <div key={index} className="flex items-center space-x-4 p-3 bg-muted/50 rounded-lg">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                          <Brain className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge variant="outline" className="text-xs">
                              {memory.type}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {memory.confidence}% confident
                            </span>
                          </div>
                          <p className="text-sm">{memory.description}</p>
                          <p className="text-xs text-muted-foreground">Learned {memory.learned}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            {/* Upcoming Tasks */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    Scheduled Tasks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {upcomingTasks.map((task) => (
                      <div key={task.id} className="p-4 border rounded-lg">
                        <h4 className="font-medium mb-2">{task.title}</h4>
                        <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
                        <div className="space-y-2 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {task.scheduledFor}
                          </div>
                          <div className="flex items-center">
                            <Target className="h-3 w-3 mr-1" />
                            {task.estimatedDuration}
                          </div>
                          <div className="flex items-center">
                            <Users className="h-3 w-3 mr-1" />
                            {task.agentType}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* AI Insights */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lightbulb className="h-5 w-5 mr-2" />
                    AI Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {insights.map((insight, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-start space-x-3">
                          <div className="h-8 w-8 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center flex-shrink-0">
                            <Lightbulb className="h-4 w-4 text-white" />
                          </div>
                          <div className="flex-1">
                            <h5 className="font-medium text-sm mb-1">{insight.title}</h5>
                            <p className="text-xs text-muted-foreground mb-2">{insight.description}</p>
                            <Button variant="outline" size="sm" className="text-xs">
                              {insight.action}
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Play className="h-4 w-4 mr-2" />
                      Start New Multi-Agent Workflow
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="h-4 w-4 mr-2" />
                      Export Project Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <BookmarkPlus className="h-4 w-4 mr-2" />
                      Browse Template Library
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Zap className="h-4 w-4 mr-2" />
                      Optimize Agent Settings
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
