import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Book,
  Search,
  ChevronRight,
  Play,
  Users,
  Brain,
  Layers,
  Eye,
  Zap,
  Code,
  FileText,
  Video,
  HelpCircle,
  ExternalLink,
  BookOpen,
  Lightbulb,
  Target,
  Rocket,
  Clock,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

const Documentation: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['getting-started']));

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sectionId)) {
        newSet.delete(sectionId);
      } else {
        newSet.add(sectionId);
      }
      return newSet;
    });
  };

  const documentationSections = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: Rocket,
      description: 'Quick start guide and basic concepts',
      items: [
        { title: 'What is MiniMax Agent?', url: '/docs/intro' },
        { title: 'Your First Project', url: '/docs/first-project' },
        { title: 'Understanding Agent Types', url: '/docs/agent-types' },
        { title: 'Basic Workflows', url: '/docs/basic-workflows' },
      ]
    },
    {
      id: 'revolutionary-features',
      title: 'Revolutionary Features',
      icon: Lightbulb,
      description: 'Advanced AI capabilities that set us apart',
      items: [
        { title: 'Multi-Agent Swarm Intelligence', url: '/docs/swarm-intelligence' },
        { title: 'Persistent Memory Systems', url: '/docs/memory-systems' },
        { title: 'Cross-Modal Intelligence', url: '/docs/cross-modal' },
        { title: 'Transparent Reasoning', url: '/docs/reasoning-chains' },
        { title: 'Real-Time Collaboration', url: '/docs/collaboration' },
        { title: 'Predictive Intelligence', url: '/docs/predictive-ai' },
      ]
    },
    {
      id: 'workflows',
      title: 'Workflow Creation',
      icon: Target,
      description: 'Building and managing complex AI workflows',
      items: [
        { title: 'Workflow Builder Interface', url: '/docs/workflow-builder' },
        { title: 'Agent Orchestration', url: '/docs/orchestration' },
        { title: 'Task Distribution', url: '/docs/task-distribution' },
        { title: 'Error Handling', url: '/docs/error-handling' },
        { title: 'Performance Optimization', url: '/docs/optimization' },
      ]
    },
    {
      id: 'agent-types',
      title: 'Agent Specializations',
      icon: Users,
      description: 'Understanding different agent capabilities',
      items: [
        { title: 'Research Agents', url: '/docs/research-agents' },
        { title: 'Creative Agents', url: '/docs/creative-agents' },
        { title: 'Analysis Agents', url: '/docs/analysis-agents' },
        { title: 'Code Generation Agents', url: '/docs/code-agents' },
        { title: 'Custom Agent Creation', url: '/docs/custom-agents' },
      ]
    },
    {
      id: 'best-practices',
      title: 'Best Practices',
      icon: BookOpen,
      description: 'Tips and strategies for optimal results',
      items: [
        { title: 'Writing Effective Prompts', url: '/docs/prompts' },
        { title: 'Choosing the Right Workflow', url: '/docs/workflow-selection' },
        { title: 'Managing Agent Memory', url: '/docs/memory-management' },
        { title: 'Performance Tips', url: '/docs/performance' },
        { title: 'Troubleshooting Guide', url: '/docs/troubleshooting' },
      ]
    },
    {
      id: 'api-reference',
      title: 'API Reference',
      icon: Code,
      description: 'Technical documentation for developers',
      items: [
        { title: 'Authentication', url: '/docs/api/auth' },
        { title: 'Workflow API', url: '/docs/api/workflows' },
        { title: 'Agent API', url: '/docs/api/agents' },
        { title: 'Webhooks', url: '/docs/api/webhooks' },
        { title: 'SDKs', url: '/docs/api/sdks' },
      ]
    },
  ];

  const quickStartGuides = [
    {
      title: 'Create Your First Multi-Agent Workflow',
      description: 'Learn to deploy agent swarms for complex tasks',
      duration: '10 min',
      difficulty: 'Beginner',
      icon: Users,
      url: '/docs/quick-start/multi-agent'
    },
    {
      title: 'Cross-Modal Project Tutorial',
      description: 'Transform content across different media types',
      duration: '15 min',
      difficulty: 'Intermediate',
      icon: Layers,
      url: '/docs/quick-start/cross-modal'
    },
    {
      title: 'Understanding Reasoning Chains',
      description: 'Explore transparent AI decision-making',
      duration: '8 min',
      difficulty: 'Beginner',
      icon: Eye,
      url: '/docs/quick-start/reasoning'
    },
    {
      title: 'Building Collaborative Workspaces',
      description: 'Set up real-time human-AI collaboration',
      duration: '20 min',
      difficulty: 'Advanced',
      icon: Zap,
      url: '/docs/quick-start/collaboration'
    },
  ];

  const featuredContent = [
    {
      type: 'Video Tutorial',
      title: 'Revolutionary AI Features Explained',
      description: 'Complete overview of breakthrough capabilities',
      duration: '12 min',
      icon: Video,
      url: '/videos/features-overview'
    },
    {
      type: 'Case Study',
      title: 'Enterprise Implementation: 10x Productivity',
      description: 'How Fortune 500 companies use MiniMax Agent',
      readTime: '8 min',
      icon: FileText,
      url: '/case-studies/enterprise'
    },
    {
      type: 'Research Paper',
      title: 'Swarm Intelligence in Practice',
      description: 'Academic research behind our agent orchestration',
      readTime: '15 min',
      icon: Book,
      url: '/research/swarm-intelligence'
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <Book className="h-8 w-8 text-white" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Documentation & Guides
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              Learn how to harness the power of revolutionary AI agent technology. 
              From basic concepts to advanced implementations.
            </p>
            
            {/* Search Bar */}
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
              <Input
                type="search"
                placeholder="Search documentation..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 h-12 text-base"
              />
            </div>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="sticky top-24"
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Documentation</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="space-y-2">
                    {documentationSections.map((section) => (
                      <Collapsible
                        key={section.id}
                        open={expandedSections.has(section.id)}
                        onOpenChange={() => toggleSection(section.id)}
                      >
                        <CollapsibleTrigger asChild>
                          <Button
                            variant="ghost"
                            className="w-full justify-start p-3 h-auto"
                          >
                            <section.icon className="h-4 w-4 mr-3" />
                            <div className="flex-1 text-left">
                              <div className="font-medium">{section.title}</div>
                              <div className="text-xs text-muted-foreground">{section.description}</div>
                            </div>
                            <ChevronRight className={`h-4 w-4 transition-transform ${
                              expandedSections.has(section.id) ? 'rotate-90' : ''
                            }`} />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="pl-10 pb-2">
                            {section.items.map((item, index) => (
                              <Button
                                key={index}
                                variant="ghost"
                                className="w-full justify-start text-sm py-1 px-2 h-auto text-muted-foreground hover:text-foreground"
                              >
                                {item.title}
                              </Button>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-8"
            >
              {/* Quick Start Guides */}
              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <Rocket className="h-6 w-6 mr-2" />
                  Quick Start Guides
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {quickStartGuides.map((guide, index) => (
                    <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer group">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="h-12 w-12 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                            <guide.icon className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                              {guide.title}
                            </h3>
                            <p className="text-sm text-muted-foreground mb-3">
                              {guide.description}
                            </p>
                            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                              <div className="flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {guide.duration}
                              </div>
                              <Badge variant="outline" className="text-xs">
                                {guide.difficulty}
                              </Badge>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                            <Play className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>

              {/* Featured Content */}
              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <Lightbulb className="h-6 w-6 mr-2" />
                  Featured Content
                </h2>
                <div className="space-y-4">
                  {featuredContent.map((content, index) => (
                    <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer group">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="h-12 w-12 rounded-lg bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                              <content.icon className="h-6 w-6 text-white" />
                            </div>
                            <div>
                              <div className="flex items-center space-x-2 mb-1">
                                <Badge variant="secondary" className="text-xs">
                                  {content.type}
                                </Badge>
                                {(content as any).duration && (
                                  <span className="text-xs text-muted-foreground">
                                    {(content as any).duration}
                                  </span>
                                )}
                                {(content as any).readTime && (
                                  <span className="text-xs text-muted-foreground">
                                    {(content as any).readTime} read
                                  </span>
                                )}
                              </div>
                              <h3 className="font-semibold group-hover:text-primary transition-colors">
                                {content.title}
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                {content.description}
                              </p>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            <ExternalLink className="h-4 w-4 mr-2" />
                            View
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>

              {/* FAQ Section */}
              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <HelpCircle className="h-6 w-6 mr-2" />
                  Frequently Asked Questions
                </h2>
                <Card>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold mb-2">What makes MiniMax Agent revolutionary?</h3>
                        <p className="text-muted-foreground">
                          MiniMax Agent introduces breakthrough concepts like multi-agent swarm intelligence, 
                          persistent memory systems, and cross-modal workflows that were previously impossible. 
                          Our agents can work together, learn from experience, and seamlessly transform content 
                          across different media types.
                        </p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-2">How does swarm intelligence work?</h3>
                        <p className="text-muted-foreground">
                          Our swarm intelligence deploys multiple specialized agents that collaborate on complex tasks. 
                          Each agent handles specific aspects of the problem, sharing insights and building on each 
                          other's work to achieve results that exceed what any single agent could accomplish.
                        </p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-2">Can I integrate MiniMax Agent with my existing tools?</h3>
                        <p className="text-muted-foreground">
                          Yes! MiniMax Agent offers comprehensive APIs and webhooks for integration with your 
                          existing workflow tools, project management systems, and business applications. 
                          Our agents can work within your current tech stack.
                        </p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-2">How do I get started with multi-agent workflows?</h3>
                        <p className="text-muted-foreground">
                          Start with our interactive tutorial that guides you through creating your first 
                          multi-agent workflow. We provide templates for common use cases and our workflow 
                          builder makes it easy to customize agent behaviors and orchestration patterns.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </section>

              {/* Community & Support */}
              <section>
                <h2 className="text-2xl font-bold mb-6">Community & Support</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold mb-3">Community Forum</h3>
                      <p className="text-muted-foreground mb-4">
                        Join thousands of users sharing workflows, best practices, and innovations.
                      </p>
                      <Button variant="outline">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Visit Forum
                      </Button>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold mb-3">Expert Support</h3>
                      <p className="text-muted-foreground mb-4">
                        Get help from our team of AI specialists and workflow experts.
                      </p>
                      <Button variant="outline">
                        <HelpCircle className="h-4 w-4 mr-2" />
                        Contact Support
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </section>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Documentation;
