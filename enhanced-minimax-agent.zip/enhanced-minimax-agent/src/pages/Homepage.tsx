import React, { useState, useEffect } from 'react';
import { motion, useAnimation, useInView } from 'framer-motion';
import { useRef } from 'react';
import {
  Search,
  Filter,
  Play,
  ArrowRight,
  Zap,
  Users,
  Brain,
  Layers,
  Eye,
  Cpu,
  ChevronDown,
  Star,
  TrendingUp,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useOnboarding } from '@/contexts/OnboardingContext';
import HeroSection from '@/components/HeroSection';
import TaskInputSection from '@/components/TaskInputSection';
import ProjectShowcase from '@/components/ProjectShowcase';
import RevolutionaryFeatures from '@/components/RevolutionaryFeatures';
import AgentSwarmDemo from '@/components/AgentSwarmDemo';
import CrossModalStudio from '@/components/CrossModalStudio';
import ReasoningChainExplorer from '@/components/ReasoningChainExplorer';

const Homepage: React.FC = () => {
  const { isFirstVisit, showOnboarding } = useOnboarding();
  const [activeFeature, setActiveFeature] = useState('workflow');

  useEffect(() => {
    if (isFirstVisit) {
      const timer = setTimeout(() => {
        showOnboarding();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isFirstVisit, showOnboarding]);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Task Input Section */}
      <TaskInputSection />

      {/* Revolutionary Features Overview */}
      <RevolutionaryFeatures />

      {/* Interactive Demos Section */}
      <section className="py-24 bg-gradient-to-b from-background to-muted/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge variant="secondary" className="mb-4">
              <Sparkles className="h-4 w-4 mr-1" />
              Interactive Demonstrations
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Experience the Future of AI
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Don't just read about revolutionary features—experience them firsthand with our interactive demos
            </p>
          </motion.div>

          <Tabs value={activeFeature} onValueChange={setActiveFeature} className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-6 mb-8">
              <TabsTrigger value="workflow" className="text-xs">Multi-Agent</TabsTrigger>
              <TabsTrigger value="swarm" className="text-xs">Agent Swarm</TabsTrigger>
              <TabsTrigger value="cross-modal" className="text-xs">Cross-Modal</TabsTrigger>
              <TabsTrigger value="reasoning" className="text-xs">Reasoning</TabsTrigger>
              <TabsTrigger value="memory" className="text-xs">Memory</TabsTrigger>
              <TabsTrigger value="collaboration" className="text-xs">Collaboration</TabsTrigger>
            </TabsList>

            <TabsContent value="workflow" className="space-y-8">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Layers className="h-6 w-6 mr-2 text-primary" />
                    Multi-Agent Workflow Builder
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted/50 rounded-lg p-6 mb-4">
                    <p className="text-center text-muted-foreground mb-4">
                      🚧 Interactive workflow builder demo coming soon! 🚧
                    </p>
                    <div className="flex justify-center">
                      <Button variant="outline" disabled>
                        <Play className="h-4 w-4 mr-2" />
                        Launch Demo
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="swarm">
              <AgentSwarmDemo />
            </TabsContent>

            <TabsContent value="cross-modal">
              <CrossModalStudio />
            </TabsContent>

            <TabsContent value="reasoning">
              <ReasoningChainExplorer />
            </TabsContent>

            <TabsContent value="memory" className="space-y-8">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="h-6 w-6 mr-2 text-primary" />
                    Agent Memory Dashboard
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted/50 rounded-lg p-6 mb-4">
                    <p className="text-center text-muted-foreground mb-4">
                      🚧 Memory dashboard demo coming soon! 🚧
                    </p>
                    <div className="flex justify-center">
                      <Button variant="outline" disabled>
                        <Brain className="h-4 w-4 mr-2" />
                        View Memory Timeline
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="collaboration" className="space-y-8">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-6 w-6 mr-2 text-primary" />
                    Real-Time Collaboration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted/50 rounded-lg p-6 mb-4">
                    <p className="text-center text-muted-foreground mb-4">
                      🚧 Collaboration workspace demo coming soon! 🚧
                    </p>
                    <div className="flex justify-center">
                      <Button variant="outline" disabled>
                        <Users className="h-4 w-4 mr-2" />
                        Start Collaboration
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Project Showcase */}
      <ProjectShowcase />

      {/* Call to Action */}
      <section className="py-24 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Experience Revolutionary AI?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Join thousands of users who are already leveraging multi-agent workflows, 
              cross-modal intelligence, and swarm computing for breakthrough results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                onClick={showOnboarding}
                className="text-lg px-8 py-3"
              >
                <Play className="h-5 w-5 mr-2" />
                Start Interactive Tour
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="text-lg px-8 py-3 text-white border-white hover:bg-white hover:text-purple-600"
              >
                <ArrowRight className="h-5 w-5 mr-2" />
                Create Your First Workflow
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Homepage;
