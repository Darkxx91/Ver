import React, { createContext, useContext, useState, ReactNode } from 'react';

interface OnboardingContextType {
  isOnboardingVisible: boolean;
  showOnboarding: () => void;
  hideOnboarding: () => void;
  currentStep: number;
  setCurrentStep: (step: number) => void;
  isFirstVisit: boolean;
  markAsVisited: () => void;
}

const OnboardingContext = createContext<OnboardingContextType | undefined>(undefined);

export const useOnboarding = () => {
  const context = useContext(OnboardingContext);
  if (!context) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
};

interface OnboardingProviderProps {
  children: ReactNode;
}

export const OnboardingProvider: React.FC<OnboardingProviderProps> = ({ children }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isFirstVisit, setIsFirstVisit] = useState(() => {
    return !localStorage.getItem('minimax-visited');
  });
  const [isOnboardingVisible, setIsOnboardingVisible] = useState(() => {
    return !localStorage.getItem('minimax-visited');
  });

  const showOnboarding = () => {
    setIsOnboardingVisible(true);
    setCurrentStep(0);
  };

  const hideOnboarding = () => {
    setIsOnboardingVisible(false);
  };

  const markAsVisited = () => {
    localStorage.setItem('minimax-visited', 'true');
    setIsFirstVisit(false);
    setIsOnboardingVisible(false);
  };

  const value = {
    isOnboardingVisible,
    showOnboarding,
    hideOnboarding,
    currentStep,
    setCurrentStep,
    isFirstVisit,
    markAsVisited,
  };

  return (
    <OnboardingContext.Provider value={value}>
      {children}
    </OnboardingContext.Provider>
  );
};
