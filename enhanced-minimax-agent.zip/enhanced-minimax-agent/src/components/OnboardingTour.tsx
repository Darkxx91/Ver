import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useOnboarding } from '@/contexts/OnboardingContext';

const onboardingSteps = [
  {
    title: 'Welcome to MiniMax Agent!',
    content: 'Your AI-powered productivity assistant that minimizes effort and maximizes intelligence.',
    target: '',
    position: 'center',
    image: '/images/onboarding-bg.jpg'
  },
  {
    title: 'Create Your First Task',
    content: 'Type your request in the input field below. Try something like "Create a website for my coffee shop" or "Analyze this data file".',
    target: '[data-tour="task-input"]',
    position: 'bottom',
  },
  {
    title: 'Explore Project Categories',
    content: 'Browse different types of projects using these category filters. Each category showcases different AI capabilities.',
    target: '[data-tour="category-filters"]',
    position: 'bottom',
  },
  {
    title: 'Enhanced Search & Filtering',
    content: 'Use the powerful search bar and advanced filters to find exactly what you need from thousands of projects.',
    target: '[data-tour="search-bar"]',
    position: 'bottom',
  },
  {
    title: 'Your Personal Dashboard',
    content: 'Access your saved projects, task history, and personalized recommendations from your dashboard.',
    target: '[data-tour="dashboard-link"]',
    position: 'bottom',
  },
  {
    title: 'Get Help Anytime',
    content: 'Visit our comprehensive documentation or start this tour again from the settings menu.',
    target: '[data-tour="help-menu"]',
    position: 'bottom',
  },
];

const OnboardingTour: React.FC = () => {
  const {
    isOnboardingVisible,
    showOnboarding,
    hideOnboarding,
    currentStep,
    setCurrentStep,
    isFirstVisit,
    markAsVisited,
  } = useOnboarding();

  useEffect(() => {
    if (isFirstVisit && !isOnboardingVisible) {
      const timer = setTimeout(() => {
        showTour();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isFirstVisit, isOnboardingVisible, showOnboarding]);

  const showTour = () => {
    showOnboarding();
  };

  const nextStep = () => {
    console.log('Next step clicked, current step:', currentStep);
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeTour();
    }
  };

  const prevStep = () => {
    console.log('Previous step clicked, current step:', currentStep);
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const completeTour = () => {
    console.log('Completing tour');
    hideOnboarding();
    markAsVisited();
  };

  const skipTour = () => {
    console.log('Skipping tour');
    hideOnboarding();
    markAsVisited();
  };

  const currentStepData = onboardingSteps[currentStep];
  const isLastStep = currentStep === onboardingSteps.length - 1;

  if (!isOnboardingVisible) return null;

  return (
    <AnimatePresence>
      {isOnboardingVisible && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={skipTour}
          />

          {/* Tour Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-[60] w-full max-w-lg mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            <Card className="border-2 border-primary/20 shadow-2xl">
              <CardHeader className="relative">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary" className="text-xs">
                      Step {currentStep + 1} of {onboardingSteps.length}
                    </Badge>
                    {isLastStep && (
                      <Badge variant="default" className="text-xs">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Final Step
                      </Badge>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      skipTour();
                    }}
                    className="h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <CardTitle className="text-xl font-bold">
                  {currentStepData.title}
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                {currentStepData.image && (
                  <div className="relative overflow-hidden rounded-lg">
                    <img
                      src={currentStepData.image}
                      alt="Onboarding illustration"
                      className="w-full h-32 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                  </div>
                )}

                <p className="text-muted-foreground leading-relaxed">
                  {currentStepData.content}
                </p>

                {/* Progress Bar */}
                <div className="w-full bg-muted rounded-full h-2">
                  <motion.div
                    className="bg-primary h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentStep + 1) / onboardingSteps.length) * 100}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between pt-4">
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        prevStep();
                      }}
                      disabled={currentStep === 0}
                    >
                      <ArrowLeft className="h-4 w-4 mr-1" />
                      Previous
                    </Button>
                  </div>

                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        skipTour();
                      }}
                    >
                      Skip Tour
                    </Button>
                    <Button 
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        nextStep();
                      }}
                    >
                      {isLastStep ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Get Started
                        </>
                      ) : (
                        <>
                          Next
                          <ArrowRight className="h-4 w-4 ml-1" />
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Spotlight Effect */}
          {currentStepData.target && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-49 pointer-events-none"
              style={{
                background: `radial-gradient(circle at center, transparent 100px, rgba(0,0,0,0.7) 200px)`,
              }}
            />
          )}
        </>
      )}
    </AnimatePresence>
  );
};

export default OnboardingTour;
