import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Filter,
  SlidersHorizontal,
  Grid,
  List,
  Calendar,
  TrendingUp,
  Star,
  ExternalLink,
  Eye,
  Clock,
  Users,
  Code,
  FileText,
  Image,
  Video,
  Zap,
  Tag,
  BookmarkPlus,
  Share2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Project {
  id: string;
  title: string;
  description: string;
  category: 'code' | 'research' | 'ppt' | 'multimodal' | 'website' | 'audio';
  tags: string[];
  complexity: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  views: number;
  likes: number;
  created: string;
  author: string;
  image: string;
  type: 'swarm' | 'single' | 'collaborative';
  featured: boolean;
}

const ProjectShowcase: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isLoading, setIsLoading] = useState(true);

  const categories = [
    { id: 'all', name: 'All Projects', icon: Grid },
    { id: 'code', name: 'Code', icon: Code },
    { id: 'research', name: 'Research', icon: FileText },
    { id: 'ppt', name: 'Presentations', icon: Image },
    { id: 'multimodal', name: 'Multimodal', icon: Video },
    { id: 'website', name: 'Websites', icon: Eye },
    { id: 'audio', name: 'Audio', icon: Video },
  ];

  const sampleProjects: Project[] = [
    {
      id: '1',
      title: 'Law Firm Website with AI Chat',
      description: 'Complete legal website with integrated AI consultation system and case management dashboard',
      category: 'website',
      tags: ['AI Assistant', 'Legal Tech', 'React', 'Multi-Agent'],
      complexity: 'advanced',
      duration: '45 minutes',
      views: 2847,
      likes: 324,
      created: '2025-01-15',
      author: 'Legal Tech Swarm',
      image: '/images/code-icon.jpg',
      type: 'swarm',
      featured: true,
    },
    {
      id: '2',
      title: 'Interactive Market Research Dashboard',
      description: 'Comprehensive competitor analysis with real-time data visualization and predictive modeling',
      category: 'research',
      tags: ['Data Analysis', 'Business Intelligence', 'Visualization'],
      complexity: 'intermediate',
      duration: '32 minutes',
      views: 1923,
      likes: 287,
      created: '2025-01-14',
      author: 'Research Collective',
      image: '/images/research-icon.jpg',
      type: 'collaborative',
      featured: true,
    },
    {
      id: '3',
      title: 'AI-Generated Children\'s Book',
      description: '20-page illustrated story with custom characters, engaging plot, and educational content',
      category: 'multimodal',
      tags: ['Creative Writing', 'Illustration', 'Education', 'Cross-Modal'],
      complexity: 'beginner',
      duration: '28 minutes',
      views: 3156,
      likes: 445,
      created: '2025-01-13',
      author: 'Creative Agent Duo',
      image: '/images/multimodal-icon.png',
      type: 'collaborative',
      featured: false,
    },
    {
      id: '4',
      title: 'Tesla Stock Analysis Report',
      description: 'Deep financial analysis with technical indicators, market sentiment, and investment recommendations',
      category: 'research',
      tags: ['Financial Analysis', 'Stock Market', 'Technical Analysis'],
      complexity: 'advanced',
      duration: '67 minutes',
      views: 4521,
      likes: 678,
      created: '2025-01-12',
      author: 'Finance Swarm',
      image: '/images/research-icon.jpg',
      type: 'swarm',
      featured: true,
    },
    {
      id: '5',
      title: 'Voxel Craft Game Engine',
      description: 'Browser-based 3D voxel game with physics, multiplayer support, and mod system',
      category: 'code',
      tags: ['Game Development', '3D Graphics', 'WebGL', 'Multiplayer'],
      complexity: 'advanced',
      duration: '156 minutes',
      views: 5834,
      likes: 892,
      created: '2025-01-11',
      author: 'Game Dev Collective',
      image: '/images/code-icon.jpg',
      type: 'swarm',
      featured: true,
    },
    {
      id: '6',
      title: 'Meditation Audio Series',
      description: 'Personalized meditation sessions with adaptive music and voice guidance',
      category: 'audio',
      tags: ['Wellness', 'Audio Generation', 'Personalization'],
      complexity: 'beginner',
      duration: '18 minutes',
      views: 2341,
      likes: 334,
      created: '2025-01-10',
      author: 'Wellness Agent',
      image: '/images/multimodal-icon.png',
      type: 'single',
      featured: false,
    },
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setProjects(sampleProjects);
      setFilteredProjects(sampleProjects);
      setIsLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = [...projects];

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(project =>
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(project => project.category === selectedCategory);
    }

    // Sort projects
    switch (sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());
        break;
      case 'popular':
        filtered.sort((a, b) => b.views - a.views);
        break;
      case 'liked':
        filtered.sort((a, b) => b.likes - a.likes);
        break;
      case 'duration':
        filtered.sort((a, b) => {
          const aDuration = parseInt(a.duration.split(' ')[0]);
          const bDuration = parseInt(b.duration.split(' ')[0]);
          return aDuration - bDuration;
        });
        break;
    }

    setFilteredProjects(filtered);
  }, [projects, searchQuery, selectedCategory, sortBy]);

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k';
    }
    return num.toString();
  };

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'beginner': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
      case 'advanced': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'swarm': return <Users className="h-3 w-3" />;
      case 'collaborative': return <Zap className="h-3 w-3" />;
      default: return <Clock className="h-3 w-3" />;
    }
  };

  return (
    <section className="py-24 bg-background" data-tour="project-showcase">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <Badge variant="secondary" className="mb-4">
            <Star className="h-4 w-4 mr-1" />
            Project Showcase
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Revolutionary AI Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explore real projects created with our revolutionary AI agent platform. 
            From simple tasks to complex multi-agent workflows.
          </p>
        </motion.div>

        {/* Search and Filter Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="mb-8"
        >
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md" data-tour="search-bar">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="search"
                placeholder="Search projects, tags, or descriptions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Controls */}
            <div className="flex items-center space-x-4">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="liked">Most Liked</SelectItem>
                  <SelectItem value="duration">Duration</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex items-center border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Category Filters */}
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} data-tour="category-filters">
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-7 mb-6">
              {categories.map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="text-xs">
                  <category.icon className="h-4 w-4 mr-1" />
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </motion.div>

        {/* Project Grid/List */}
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="h-48 bg-muted animate-pulse" />
                  <CardContent className="p-4 space-y-3">
                    <div className="h-4 bg-muted animate-pulse rounded" />
                    <div className="h-3 bg-muted animate-pulse rounded w-2/3" />
                    <div className="flex space-x-2">
                      <div className="h-5 bg-muted animate-pulse rounded w-16" />
                      <div className="h-5 bg-muted animate-pulse rounded w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className={
                viewMode === 'grid'
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                  : 'space-y-4'
              }
            >
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  {viewMode === 'grid' ? (
                    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 group border-2 border-transparent hover:border-primary/20">
                      {project.featured && (
                        <div className="absolute top-2 left-2 z-10">
                          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500">
                            <Star className="h-3 w-3 mr-1" />
                            Featured
                          </Badge>
                        </div>
                      )}
                      
                      <div className="relative overflow-hidden">
                        <img
                          src={project.image}
                          alt={project.title}
                          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <Button size="sm" variant="secondary">
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </Button>
                        </div>
                      </div>

                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-lg leading-tight group-hover:text-primary transition-colors">
                            {project.title}
                          </h3>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <SlidersHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <BookmarkPlus className="h-4 w-4 mr-2" />
                                Save Project
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Share2 className="h-4 w-4 mr-2" />
                                Share
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <ExternalLink className="h-4 w-4 mr-2" />
                                Open in New Tab
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                          {project.description}
                        </p>

                        <div className="flex flex-wrap gap-1 mb-3">
                          {project.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {project.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{project.tags.length - 3}
                            </Badge>
                          )}
                        </div>

                        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                          <div className="flex items-center space-x-2">
                            <div className="flex items-center">
                              {getTypeIcon(project.type)}
                              <span className="ml-1 capitalize">{project.type}</span>
                            </div>
                            <span>•</span>
                            <span>{project.duration}</span>
                          </div>
                          <Badge className={getComplexityColor(project.complexity)}>
                            {project.complexity}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                            <div className="flex items-center">
                              <Eye className="h-3 w-3 mr-1" />
                              {formatNumber(project.views)}
                            </div>
                            <div className="flex items-center">
                              <Star className="h-3 w-3 mr-1" />
                              {formatNumber(project.likes)}
                            </div>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            by {project.author}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-2 border-transparent hover:border-primary/20">
                      <div className="flex">
                        <img
                          src={project.image}
                          alt={project.title}
                          className="w-32 h-32 object-cover flex-shrink-0"
                        />
                        <CardContent className="flex-1 p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <h3 className="font-semibold text-lg">{project.title}</h3>
                                {project.featured && (
                                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500">
                                    <Star className="h-3 w-3 mr-1" />
                                    Featured
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {project.description}
                              </p>
                              <div className="flex flex-wrap gap-1 mb-2">
                                {project.tags.slice(0, 4).map((tag) => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex items-center space-x-2 ml-4">
                              <div className="text-right text-xs text-muted-foreground">
                                <div className="flex items-center mb-1">
                                  <Eye className="h-3 w-3 mr-1" />
                                  {formatNumber(project.views)}
                                </div>
                                <div className="flex items-center">
                                  <Star className="h-3 w-3 mr-1" />
                                  {formatNumber(project.likes)}
                                </div>
                              </div>
                              <Button size="sm">
                                <Eye className="h-4 w-4 mr-2" />
                                View
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </div>
                    </Card>
                  )}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Load More */}
        {!isLoading && filteredProjects.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <Button variant="outline" size="lg">
              Load More Projects
            </Button>
          </motion.div>
        )}

        {/* No Results */}
        {!isLoading && filteredProjects.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No projects found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search criteria or explore different categories
            </p>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default ProjectShowcase;
