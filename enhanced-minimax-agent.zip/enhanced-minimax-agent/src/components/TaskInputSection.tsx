import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send,
  Mic,
  Image,
  Paperclip,
  Sparkles,
  Zap,
  Clock,
  Users,
  Brain,
  ChevronDown,
  Play,
  Settings,
  Wand2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Card, CardContent } from '@/components/ui/card';

const TaskInputSection: React.FC = () => {
  const [task, setTask] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState('auto');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const workflowTypes = [
    { id: 'auto', name: 'Auto-Select', icon: Wand2, description: 'AI chooses optimal workflow' },
    { id: 'multi-agent', name: 'Multi-Agent', icon: Users, description: 'Deploy agent swarm' },
    { id: 'single', name: 'Single Agent', icon: Brain, description: 'Focused single agent' },
    { id: 'realtime', name: 'Real-Time', icon: Zap, description: 'Live collaboration' },
  ];

  const quickTemplates = [
    'Create a comprehensive market research report for [industry]',
    'Build a complete website with modern design for [business type]',
    'Analyze this dataset and provide actionable insights',
    'Generate a multi-modal marketing campaign including video, audio, and visuals',
    'Write and illustrate a children\'s book about [topic]',
    'Create a technical documentation with diagrams for [project]',
  ];

  const handleSubmit = async () => {
    if (!task.trim()) return;
    
    setIsProcessing(true);
    // Simulate processing
    setTimeout(() => {
      setIsProcessing(false);
      setTask('');
    }, 3000);
  };

  const handleTemplateSelect = (template: string) => {
    setTask(template);
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  const handleFileUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <section className="py-24 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4">
              <Sparkles className="h-4 w-4 mr-1" />
              Revolutionary Task Interface
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What would you like to create today?
            </h2>
            <p className="text-lg text-muted-foreground">
              From simple tasks to complex multi-modal projects, our AI agents are ready to help
            </p>
          </div>

          <Card className="border-2 border-primary/20 shadow-2xl" data-tour="task-input">
            <CardContent className="p-6">
              {/* Workflow Selection */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">Workflow Type:</span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" className="text-sm">
                        {workflowTypes.find(w => w.id === selectedWorkflow)?.icon && 
                          React.createElement(workflowTypes.find(w => w.id === selectedWorkflow)!.icon, { className: "h-4 w-4 mr-2" })
                        }
                        {workflowTypes.find(w => w.id === selectedWorkflow)?.name}
                        <ChevronDown className="h-4 w-4 ml-2" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      {workflowTypes.map((workflow) => (
                        <DropdownMenuItem
                          key={workflow.id}
                          onClick={() => setSelectedWorkflow(workflow.id)}
                        >
                          <workflow.icon className="h-4 w-4 mr-2" />
                          <div>
                            <div className="font-medium">{workflow.name}</div>
                            <div className="text-xs text-muted-foreground">{workflow.description}</div>
                          </div>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    Real-time
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    <Users className="h-3 w-3 mr-1" />
                    Multi-agent ready
                  </Badge>
                </div>
              </div>

              {/* Main Input Area */}
              <div className="relative">
                <Textarea
                  value={task}
                  onChange={(e) => setTask(e.target.value)}
                  placeholder="Describe your task in natural language... Be as detailed or as simple as you like. Our AI will understand and create the perfect workflow for you."
                  className="min-h-[120px] text-base resize-none pr-24 border-2 focus:border-primary/30"
                  disabled={isProcessing}
                />
                
                {/* Input Actions */}
                <div className="absolute bottom-3 right-3 flex items-center space-x-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleFileUpload}
                          className="h-8 w-8 p-0"
                        >
                          <Paperclip className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Upload files (images, documents, code, etc.)</p>
                      </TooltipContent>
                    </Tooltip>

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={toggleRecording}
                          className={`h-8 w-8 p-0 ${isRecording ? 'text-red-500 animate-pulse' : ''}`}
                        >
                          <Mic className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Voice input</p>
                      </TooltipContent>
                    </Tooltip>

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                        >
                          <Image className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Upload image for analysis</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span>Press</span>
                  <Badge variant="outline" className="text-xs px-2 py-1">Ctrl + Enter</Badge>
                  <span>to submit</span>
                </div>
                
                <Button
                  onClick={handleSubmit}
                  disabled={!task.trim() || isProcessing}
                  size="lg"
                  className="px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {isProcessing ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </div>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Run Task
                      <Send className="h-4 w-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>

              {/* Processing Animation */}
              <AnimatePresence>
                {isProcessing && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg border"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                      <div>
                        <p className="font-medium">Analyzing your request...</p>
                        <p className="text-sm text-muted-foreground">Setting up optimal agent workflow</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>

          {/* Quick Templates */}
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4 text-center">Quick Start Templates</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {quickTemplates.map((template, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  onClick={() => handleTemplateSelect(template)}
                  className="p-4 text-left bg-muted/50 hover:bg-muted/80 rounded-lg border border-transparent hover:border-primary/20 transition-all group"
                >
                  <div className="flex items-start space-x-3">
                    <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <Sparkles className="h-4 w-4 text-white" />
                    </div>
                    <p className="text-sm leading-relaxed group-hover:text-foreground transition-colors">
                      {template}
                    </p>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            accept="*/*"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default TaskInputSection;
