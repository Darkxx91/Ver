import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload,
  Image,
  FileText,
  Music,
  Video,
  Code,
  ArrowRight,
  Download,
  Play,
  Zap,
  Layers,
  RefreshCw,
  CheckCircle,
  Clock,
  Wand2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface MediaFile {
  id: string;
  name: string;
  type: 'image' | 'text' | 'audio' | 'video' | 'code';
  url: string;
  size: string;
}

interface TransformationStep {
  id: string;
  from: string;
  to: string;
  status: 'pending' | 'processing' | 'completed';
  progress: number;
  duration: number;
}

const CrossModalStudio: React.FC = () => {
  const [uploadedFiles, setUploadedFiles] = useState<MediaFile[]>([]);
  const [selectedPipeline, setSelectedPipeline] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [transformationSteps, setTransformationSteps] = useState<TransformationStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const mediaTypes = {
    image: { icon: Image, color: 'from-blue-500 to-blue-600', bgColor: 'bg-blue-50 dark:bg-blue-950/20' },
    text: { icon: FileText, color: 'from-green-500 to-green-600', bgColor: 'bg-green-50 dark:bg-green-950/20' },
    audio: { icon: Music, color: 'from-purple-500 to-purple-600', bgColor: 'bg-purple-50 dark:bg-purple-950/20' },
    video: { icon: Video, color: 'from-red-500 to-red-600', bgColor: 'bg-red-50 dark:bg-red-950/20' },
    code: { icon: Code, color: 'from-orange-500 to-orange-600', bgColor: 'bg-orange-50 dark:bg-orange-950/20' },
  };

  const predefinedPipelines = [
    {
      id: 'content-suite',
      name: 'Complete Content Suite',
      description: 'Transform a single concept into multi-modal content',
      steps: [
        { from: 'text', to: 'image', label: 'Generate Visuals' },
        { from: 'image', to: 'video', label: 'Create Video' },
        { from: 'text', to: 'audio', label: 'Generate Narration' },
        { from: 'video', to: 'text', label: 'Create Documentation' },
      ]
    },
    {
      id: 'app-development',
      name: 'App Development Pipeline',
      description: 'From sketch to working application',
      steps: [
        { from: 'image', to: 'code', label: 'UI to Code' },
        { from: 'code', to: 'text', label: 'Generate Docs' },
        { from: 'text', to: 'video', label: 'Create Tutorial' },
        { from: 'code', to: 'image', label: 'Visual Diagrams' },
      ]
    },
    {
      id: 'research-report',
      name: 'Research Report Suite',
      description: 'Transform data into comprehensive multimedia report',
      steps: [
        { from: 'text', to: 'image', label: 'Data Visualization' },
        { from: 'text', to: 'audio', label: 'Audio Summary' },
        { from: 'image', to: 'video', label: 'Presentation Video' },
        { from: 'video', to: 'text', label: 'Executive Summary' },
      ]
    }
  ];

  const sampleFiles: MediaFile[] = [
    {
      id: '1',
      name: 'Product Concept.txt',
      type: 'text',
      url: '/sample/concept.txt',
      size: '2.4 KB'
    },
    {
      id: '2',
      name: 'UI Sketch.jpg',
      type: 'image',
      url: '/images/code-icon.jpg',
      size: '156 KB'
    },
    {
      id: '3',
      name: 'Demo Script.md',
      type: 'text',
      url: '/sample/script.md',
      size: '3.7 KB'
    }
  ];

  const handleFileUpload = () => {
    fileInputRef.current?.click();
  };

  const loadSampleFiles = () => {
    setUploadedFiles(sampleFiles);
  };

  const startPipeline = (pipelineId: string) => {
    const pipeline = predefinedPipelines.find(p => p.id === pipelineId);
    if (!pipeline) return;

    setSelectedPipeline(pipelineId);
    setIsProcessing(true);
    setCurrentStep(0);

    const steps: TransformationStep[] = pipeline.steps.map((step, index) => ({
      id: `step-${index}`,
      from: step.from,
      to: step.to,
      status: 'pending',
      progress: 0,
      duration: Math.random() * 3 + 2 // 2-5 seconds
    }));

    setTransformationSteps(steps);

    // Simulate processing
    let stepIndex = 0;
    const processStep = () => {
      if (stepIndex >= steps.length) {
        setIsProcessing(false);
        return;
      }

      setCurrentStep(stepIndex);
      const step = steps[stepIndex];
      step.status = 'processing';
      setTransformationSteps([...steps]);

      // Simulate progress
      const progressInterval = setInterval(() => {
        step.progress += Math.random() * 20;
        if (step.progress >= 100) {
          step.progress = 100;
          step.status = 'completed';
          clearInterval(progressInterval);
          stepIndex++;
          setTimeout(processStep, 500);
        }
        setTransformationSteps([...steps]);
      }, 200);
    };

    processStep();
  };

  const resetPipeline = () => {
    setIsProcessing(false);
    setSelectedPipeline('');
    setTransformationSteps([]);
    setCurrentStep(0);
  };

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Layers className="h-6 w-6 mr-2 text-primary" />
          Cross-Modal Project Studio
        </CardTitle>
        <p className="text-muted-foreground">
          Upload any media type and watch it transform across different modalities
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="upload">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upload">Upload & Input</TabsTrigger>
            <TabsTrigger value="pipeline">Pipeline Design</TabsTrigger>
            <TabsTrigger value="results">Results & Export</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-4">
            {/* File Upload Area */}
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center space-y-4">
              <div className="flex justify-center">
                <div className="h-16 w-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                  <Upload className="h-8 w-8 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Upload Your Media</h3>
                <p className="text-muted-foreground mb-4">
                  Support for images, text, audio, video, and code files
                </p>
                <div className="flex justify-center space-x-4">
                  <Button onClick={handleFileUpload}>
                    <Upload className="h-4 w-4 mr-2" />
                    Choose Files
                  </Button>
                  <Button variant="outline" onClick={loadSampleFiles}>
                    <Wand2 className="h-4 w-4 mr-2" />
                    Load Sample Files
                  </Button>
                </div>
              </div>
            </div>

            {/* Uploaded Files */}
            {uploadedFiles.length > 0 && (
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Uploaded Files</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {uploadedFiles.map((file) => {
                    const mediaType = mediaTypes[file.type];
                    return (
                      <motion.div
                        key={file.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={`p-4 rounded-lg border ${mediaType.bgColor}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`h-10 w-10 rounded-lg bg-gradient-to-r ${mediaType.color} flex items-center justify-center`}>
                            <mediaType.icon className="h-5 w-5 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{file.name}</p>
                            <p className="text-xs text-muted-foreground">{file.size}</p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="pipeline" className="space-y-4">
            {/* Predefined Pipelines */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium">Choose a Transformation Pipeline</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {predefinedPipelines.map((pipeline) => (
                  <Card 
                    key={pipeline.id} 
                    className={`cursor-pointer transition-all ${
                      selectedPipeline === pipeline.id 
                        ? 'border-primary bg-primary/5' 
                        : 'hover:border-primary/50'
                    }`}
                    onClick={() => !isProcessing && startPipeline(pipeline.id)}
                  >
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">{pipeline.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{pipeline.description}</p>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {pipeline.steps.map((step, index) => (
                          <div key={index} className="flex items-center text-xs">
                            <div className={`h-6 w-6 rounded bg-gradient-to-r ${mediaTypes[step.from as keyof typeof mediaTypes].color} flex items-center justify-center mr-2`}>
                              <span className="text-white text-xs">
                                {React.createElement(mediaTypes[step.from as keyof typeof mediaTypes].icon, { className: "h-3 w-3" })}
                              </span>
                            </div>
                            <ArrowRight className="h-3 w-3 mx-1 text-muted-foreground" />
                            <div className={`h-6 w-6 rounded bg-gradient-to-r ${mediaTypes[step.to as keyof typeof mediaTypes].color} flex items-center justify-center mr-2`}>
                              <span className="text-white text-xs">
                                {React.createElement(mediaTypes[step.to as keyof typeof mediaTypes].icon, { className: "h-3 w-3" })}
                              </span>
                            </div>
                            <span className="text-muted-foreground">{step.label}</span>
                          </div>
                        ))}
                      </div>
                      {selectedPipeline === pipeline.id && !isProcessing && (
                        <Button size="sm" className="w-full mt-3">
                          <Play className="h-4 w-4 mr-2" />
                          Start Pipeline
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Processing Visualization */}
            <AnimatePresence>
              {isProcessing && transformationSteps.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg border"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium flex items-center">
                      <Zap className="h-4 w-4 mr-2" />
                      Pipeline Processing
                    </h4>
                    <Button variant="outline" size="sm" onClick={resetPipeline}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    {transformationSteps.map((step, index) => (
                      <div key={step.id} className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <div className={`h-8 w-8 rounded bg-gradient-to-r ${mediaTypes[step.from as keyof typeof mediaTypes].color} flex items-center justify-center`}>
                            {React.createElement(mediaTypes[step.from as keyof typeof mediaTypes].icon, { className: "h-4 w-4 text-white" })}
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                          <div className={`h-8 w-8 rounded bg-gradient-to-r ${mediaTypes[step.to as keyof typeof mediaTypes].color} flex items-center justify-center`}>
                            {React.createElement(mediaTypes[step.to as keyof typeof mediaTypes].icon, { className: "h-4 w-4 text-white" })}
                          </div>
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center justify-between text-sm">
                            <span>Step {index + 1}</span>
                            <div className="flex items-center space-x-2">
                              {step.status === 'completed' && <CheckCircle className="h-4 w-4 text-green-500" />}
                              {step.status === 'processing' && <div className="h-4 w-4 rounded-full bg-yellow-500 animate-pulse" />}
                              {step.status === 'pending' && <Clock className="h-4 w-4 text-muted-foreground" />}
                              <span className="text-xs text-muted-foreground">
                                {Math.round(step.progress)}%
                              </span>
                            </div>
                          </div>
                          <Progress value={step.progress} className="h-2 mt-1" />
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </TabsContent>

          <TabsContent value="results" className="space-y-4">
            <div className="text-center py-8">
              <div className="h-16 w-16 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center mx-auto mb-4">
                <Download className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Results Ready</h3>
              <p className="text-muted-foreground mb-4">
                Your cross-modal transformation is complete. Download your results below.
              </p>
              <div className="flex justify-center space-x-4">
                <Button>
                  <Download className="h-4 w-4 mr-2" />
                  Download All
                </Button>
                <Button variant="outline">
                  <Play className="h-4 w-4 mr-2" />
                  Preview Results
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          accept="*/*"
        />
      </CardContent>
    </Card>
  );
};

export default CrossModalStudio;
