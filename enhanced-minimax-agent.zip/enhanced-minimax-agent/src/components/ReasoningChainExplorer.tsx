import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Eye,
  GitBranch,
  Play,
  Pause,
  RotateCcw,
  ChevronDown,
  ChevronRight,
  Lightbulb,
  AlertTriangle,
  CheckCircle,
  Clock,
  Brain,
  Target,
  Zap,
  Settings,
  TrendingUp,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

interface ReasoningStep {
  id: string;
  title: string;
  description: string;
  reasoning: string;
  confidence: number;
  status: 'pending' | 'active' | 'completed' | 'alternative';
  type: 'analysis' | 'decision' | 'evaluation' | 'synthesis';
  alternatives?: AlternativePath[];
  evidences: Evidence[];
  duration: number;
}

interface AlternativePath {
  id: string;
  title: string;
  confidence: number;
  reasoning: string;
}

interface Evidence {
  type: 'data' | 'logic' | 'example' | 'expert';
  content: string;
  weight: number;
}

const ReasoningChainExplorer: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [steps, setSteps] = useState<ReasoningStep[]>([]);
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());
  const [confidenceThreshold, setConfidenceThreshold] = useState([70]);
  const [selectedAlternative, setSelectedAlternative] = useState<string | null>(null);

  const stepTypes = {
    analysis: { icon: Brain, color: 'from-blue-500 to-blue-600', bgColor: 'bg-blue-50 dark:bg-blue-950/20' },
    decision: { icon: Target, color: 'from-green-500 to-green-600', bgColor: 'bg-green-50 dark:bg-green-950/20' },
    evaluation: { icon: TrendingUp, color: 'from-purple-500 to-purple-600', bgColor: 'bg-purple-50 dark:bg-purple-950/20' },
    synthesis: { icon: Lightbulb, color: 'from-orange-500 to-orange-600', bgColor: 'bg-orange-50 dark:bg-orange-950/20' },
  };

  const sampleSteps: ReasoningStep[] = [
    {
      id: '1',
      title: 'Problem Analysis',
      description: 'Understanding the core challenge and constraints',
      reasoning: 'The user wants to create a comprehensive market research report. I need to identify key market segments, competitive landscape, and data sources.',
      confidence: 95,
      status: 'pending',
      type: 'analysis',
      evidences: [
        { type: 'data', content: 'Market size data available from 3 reliable sources', weight: 0.8 },
        { type: 'logic', content: 'Standard market research methodology applies', weight: 0.9 },
      ],
      duration: 2.5,
    },
    {
      id: '2',
      title: 'Data Collection Strategy',
      description: 'Determining optimal data sources and collection methods',
      reasoning: 'Based on the analysis, I should prioritize recent industry reports, competitor financial data, and customer sentiment analysis.',
      confidence: 85,
      status: 'pending',
      type: 'decision',
      alternatives: [
        { id: 'alt1', title: 'Focus on quantitative data only', confidence: 75, reasoning: 'Faster but less comprehensive' },
        { id: 'alt2', title: 'Include qualitative interviews', confidence: 90, reasoning: 'More insights but time-intensive' },
      ],
      evidences: [
        { type: 'expert', content: 'Industry best practices recommend mixed methods', weight: 0.85 },
        { type: 'example', content: 'Similar successful reports used this approach', weight: 0.7 },
      ],
      duration: 3.0,
    },
    {
      id: '3',
      title: 'Source Evaluation',
      description: 'Assessing reliability and relevance of data sources',
      reasoning: 'I will cross-reference multiple sources and weight them by recency, authority, and methodology quality.',
      confidence: 78,
      status: 'pending',
      type: 'evaluation',
      evidences: [
        { type: 'logic', content: 'Source triangulation improves accuracy', weight: 0.9 },
        { type: 'data', content: '15 high-quality sources identified', weight: 0.8 },
      ],
      duration: 1.8,
    },
    {
      id: '4',
      title: 'Report Synthesis',
      description: 'Combining insights into coherent recommendations',
      reasoning: 'I will structure findings into executive summary, market overview, competitive analysis, and strategic recommendations.',
      confidence: 92,
      status: 'pending',
      type: 'synthesis',
      evidences: [
        { type: 'example', content: 'This structure proven effective in 100+ reports', weight: 0.95 },
        { type: 'logic', content: 'Logical flow from data to recommendations', weight: 0.85 },
      ],
      duration: 4.2,
    },
  ];

  const initializeReasoning = () => {
    setSteps(sampleSteps.map(step => ({ ...step, status: 'pending' })));
    setCurrentStepIndex(0);
    setExpandedSteps(new Set());
    setSelectedAlternative(null);
  };

  const startReasoning = () => {
    setIsRunning(true);
    let stepIndex = 0;

    const processStep = () => {
      if (stepIndex >= steps.length) {
        setIsRunning(false);
        return;
      }

      setCurrentStepIndex(stepIndex);
      
      // Update step status
      const updatedSteps = [...steps];
      updatedSteps[stepIndex].status = 'active';
      setSteps(updatedSteps);

      // Auto-expand current step
      setExpandedSteps(prev => new Set([...prev, updatedSteps[stepIndex].id]));

      // Complete step after duration
      setTimeout(() => {
        updatedSteps[stepIndex].status = 'completed';
        setSteps([...updatedSteps]);
        stepIndex++;
        setTimeout(processStep, 500);
      }, updatedSteps[stepIndex].duration * 1000);
    };

    processStep();
  };

  const resetReasoning = () => {
    setIsRunning(false);
    initializeReasoning();
  };

  const toggleStepExpansion = (stepId: string) => {
    setExpandedSteps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(stepId)) {
        newSet.delete(stepId);
      } else {
        newSet.add(stepId);
      }
      return newSet;
    });
  };

  const selectAlternative = (stepId: string, alternativeId: string) => {
    setSelectedAlternative(alternativeId);
    // In a real implementation, this would trigger re-computation of subsequent steps
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-600';
    if (confidence >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusIcon = (status: ReasoningStep['status']) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4 text-muted-foreground" />;
      case 'active': return <div className="h-4 w-4 rounded-full bg-blue-500 animate-pulse" />;
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'alternative': return <GitBranch className="h-4 w-4 text-purple-500" />;
    }
  };

  useEffect(() => {
    initializeReasoning();
  }, []);

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Eye className="h-6 w-6 mr-2 text-primary" />
            Reasoning Chain Explorer
          </CardTitle>
          <Badge variant={isRunning ? 'default' : 'secondary'}>
            {isRunning ? 'Analyzing' : 'Ready'}
          </Badge>
        </div>
        <p className="text-muted-foreground">
          Watch how AI agents make decisions with transparent, step-by-step reasoning
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Control Panel */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center space-x-4">
            <Button
              onClick={isRunning ? () => setIsRunning(false) : startReasoning}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {isRunning ? (
                <>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause Reasoning
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Start Reasoning
                </>
              )}
            </Button>
            <Button variant="outline" onClick={resetReasoning}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm">Confidence Threshold:</span>
              <div className="w-20">
                <Slider
                  value={confidenceThreshold}
                  onValueChange={setConfidenceThreshold}
                  max={100}
                  min={0}
                  step={5}
                  className="w-full"
                />
              </div>
              <span className="text-sm font-medium">{confidenceThreshold[0]}%</span>
            </div>
          </div>
        </div>

        {/* Reasoning Steps */}
        <div className="space-y-4">
          {steps.map((step, index) => {
            const isExpanded = expandedSteps.has(step.id);
            const stepType = stepTypes[step.type];
            const isCurrentStep = index === currentStepIndex && isRunning;
            const meetsThreshold = step.confidence >= confidenceThreshold[0];

            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`border rounded-lg ${
                  isCurrentStep ? 'border-primary shadow-lg' : 'border-border'
                } ${!meetsThreshold ? 'opacity-50' : ''}`}
              >
                <Collapsible open={isExpanded} onOpenChange={() => toggleStepExpansion(step.id)}>
                  <CollapsibleTrigger asChild>
                    <div className="p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <div className={`h-8 w-8 rounded-lg bg-gradient-to-r ${stepType.color} flex items-center justify-center`}>
                              <stepType.icon className="h-4 w-4 text-white" />
                            </div>
                            {getStatusIcon(step.status)}
                          </div>
                          <div>
                            <h4 className="font-medium">{step.title}</h4>
                            <p className="text-sm text-muted-foreground">{step.description}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <div className={`text-sm font-semibold ${getConfidenceColor(step.confidence)}`}>
                              {step.confidence}% confident
                            </div>
                            {step.status === 'active' && (
                              <div className="text-xs text-muted-foreground">
                                ~{step.duration}s remaining
                              </div>
                            )}
                          </div>
                          {isExpanded ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </div>
                      </div>
                      
                      {/* Progress bar for active step */}
                      {step.status === 'active' && (
                        <div className="mt-3">
                          <Progress value={(currentStepIndex / steps.length) * 100} className="h-1" />
                        </div>
                      )}
                    </div>
                  </CollapsibleTrigger>
                  
                  <CollapsibleContent>
                    <div className="px-4 pb-4 space-y-4 border-t bg-muted/20">
                      {/* Reasoning */}
                      <div className="pt-4">
                        <h5 className="text-sm font-medium mb-2 flex items-center">
                          <Brain className="h-4 w-4 mr-2" />
                          Reasoning Process
                        </h5>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {step.reasoning}
                        </p>
                      </div>

                      {/* Evidence */}
                      <div>
                        <h5 className="text-sm font-medium mb-2 flex items-center">
                          <Zap className="h-4 w-4 mr-2" />
                          Supporting Evidence
                        </h5>
                        <div className="space-y-2">
                          {step.evidences.map((evidence, idx) => (
                            <div key={idx} className="flex items-center space-x-3 text-sm">
                              <Badge variant="outline" className="text-xs">
                                {evidence.type}
                              </Badge>
                              <span className="flex-1">{evidence.content}</span>
                              <div className="text-xs text-muted-foreground">
                                Weight: {Math.round(evidence.weight * 100)}%
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Alternatives */}
                      {step.alternatives && step.alternatives.length > 0 && (
                        <div>
                          <h5 className="text-sm font-medium mb-2 flex items-center">
                            <GitBranch className="h-4 w-4 mr-2" />
                            Alternative Approaches
                          </h5>
                          <div className="space-y-2">
                            {step.alternatives.map((alt) => (
                              <div
                                key={alt.id}
                                className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                                  selectedAlternative === alt.id
                                    ? 'border-primary bg-primary/5'
                                    : 'border-border hover:border-primary/50'
                                }`}
                                onClick={() => selectAlternative(step.id, alt.id)}
                              >
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-sm font-medium">{alt.title}</span>
                                  <span className={`text-xs ${getConfidenceColor(alt.confidence)}`}>
                                    {alt.confidence}%
                                  </span>
                                </div>
                                <p className="text-xs text-muted-foreground">{alt.reasoning}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Confidence Analysis */}
                      <div>
                        <h5 className="text-sm font-medium mb-2">Confidence Breakdown</h5>
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Logic Quality</span>
                            <span>92%</span>
                          </div>
                          <Progress value={92} className="h-1" />
                          <div className="flex justify-between text-xs">
                            <span>Evidence Strength</span>
                            <span>85%</span>
                          </div>
                          <Progress value={85} className="h-1" />
                          <div className="flex justify-between text-xs">
                            <span>Uncertainty</span>
                            <span>12%</span>
                          </div>
                          <Progress value={12} className="h-1" />
                        </div>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </motion.div>
            );
          })}
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">
              {steps.filter(s => s.status === 'completed').length}
            </div>
            <div className="text-xs text-muted-foreground">Steps Completed</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              {Math.round(steps.reduce((acc, step) => acc + step.confidence, 0) / steps.length)}%
            </div>
            <div className="text-xs text-muted-foreground">Avg Confidence</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">
              {steps.reduce((acc, step) => acc + step.evidences.length, 0)}
            </div>
            <div className="text-xs text-muted-foreground">Evidence Points</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              {steps.reduce((acc, step) => acc + (step.alternatives?.length || 0), 0)}
            </div>
            <div className="text-xs text-muted-foreground">Alternatives</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReasoningChainExplorer;
