import React from 'react';
import { motion } from 'framer-motion';
import {
  Users,
  Brain,
  Layers,
  Eye,
  Zap,
  Network,
  Cpu,
  GitBranch,
  Clock,
  Lightbulb,
  Target,
  Shield,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const RevolutionaryFeatures: React.FC = () => {
  const features = [
    {
      icon: Users,
      title: 'Multi-Agent Swarm Intelligence',
      description: 'Deploy teams of specialized agents that collaborate to solve complex problems faster than any single agent could.',
      highlights: ['Emergent Intelligence', 'Dynamic Task Distribution', 'Fault-Tolerant Networks'],
      gradient: 'from-blue-500 to-cyan-500',
      status: 'Live Demo Available'
    },
    {
      icon: Brain,
      title: 'Persistent Memory Systems',
      description: 'Agents that remember context across weeks, learn your preferences, and continuously improve their performance.',
      highlights: ['Session Persistence', 'Relationship Mapping', 'Skill Accumulation'],
      gradient: 'from-purple-500 to-pink-500',
      status: 'Beta Testing'
    },
    {
      icon: Layers,
      title: 'Cross-Modal Intelligence',
      description: 'Seamlessly transform between text, images, audio, video, and code in unified workflows.',
      highlights: ['Vision-Language-Action', 'Multimodal Chains', 'Real-World Understanding'],
      gradient: 'from-green-500 to-teal-500',
      status: 'Live Demo Available'
    },
    {
      icon: Eye,
      title: 'Transparent Reasoning',
      description: 'See exactly how agents make decisions with interactive reasoning chains and confidence scoring.',
      highlights: ['Decision Visualization', 'Interactive Modification', 'Confidence Scoring'],
      gradient: 'from-orange-500 to-red-500',
      status: 'Live Demo Available'
    },
    {
      icon: Zap,
      title: 'Real-Time Collaboration',
      description: 'Work alongside agents in shared workspaces with live updates and seamless human-AI handoffs.',
      highlights: ['Live Multi-User Sessions', 'Role-Based Collaboration', 'Synchronized Workspaces'],
      gradient: 'from-yellow-500 to-orange-500',
      status: 'Coming Soon'
    },
    {
      icon: Lightbulb,
      title: 'Predictive Intelligence',
      description: 'Agents that anticipate your needs, work autonomously overnight, and proactively solve problems.',
      highlights: ['Anticipatory Computing', 'Scheduled Intelligence', 'Environmental Awareness'],
      gradient: 'from-indigo-500 to-purple-500',
      status: 'Research Phase'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6
      }
    }
  };

  return (
    <section className="py-24 bg-gradient-to-b from-muted/20 to-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge variant="secondary" className="mb-4">
            <Network className="h-4 w-4 mr-1" />
            Revolutionary Capabilities
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            The Future of AI is Here
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience breakthrough AI technologies that were thought impossible just months ago. 
            These aren't just features—they're paradigm shifts in how humans and AI collaborate.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {features.map((feature, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full border-2 border-transparent hover:border-primary/20 transition-all duration-300 group hover:shadow-xl">
                <CardHeader className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`h-12 w-12 rounded-xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <Badge 
                      variant={feature.status === 'Live Demo Available' ? 'default' : 
                               feature.status === 'Beta Testing' ? 'secondary' : 'outline'}
                      className="text-xs"
                    >
                      {feature.status}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Key Capabilities:</p>
                    <ul className="space-y-1">
                      {feature.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-center text-sm text-muted-foreground">
                          <div className={`h-1.5 w-1.5 rounded-full bg-gradient-to-r ${feature.gradient} mr-2`} />
                          {highlight}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {feature.status === 'Live Demo Available' && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Try Interactive Demo
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Technical Breakthrough Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-2xl p-8 md:p-12 border border-primary/10">
            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <Cpu className="h-8 w-8 text-white" />
              </div>
            </div>
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              10x Productivity Breakthrough
            </h3>
            <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
              Our revolutionary AI architecture delivers results that would take traditional tools days to complete—in minutes.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">100+</div>
                <div className="text-sm text-muted-foreground">Agents working simultaneously</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">10x</div>
                <div className="text-sm text-muted-foreground">Faster than single-agent systems</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">∞</div>
                <div className="text-sm text-muted-foreground">Possibilities with cross-modal AI</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default RevolutionaryFeatures;
