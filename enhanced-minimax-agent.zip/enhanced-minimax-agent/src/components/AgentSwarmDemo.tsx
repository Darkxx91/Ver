import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Play,
  Pause,
  RotateCcw,
  Zap,
  Users,
  TrendingUp,
  Clock,
  CheckCircle,
  Circle,
  AlertCircle,
  Brain,
  Network,
  Target,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface Agent {
  id: number;
  type: 'researcher' | 'analyst' | 'writer' | 'validator';
  status: 'idle' | 'working' | 'completed' | 'collaborating';
  task: string;
  progress: number;
  x: number;
  y: number;
  connections: number[];
}

const AgentSwarmDemo: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [overallProgress, setOverallProgress] = useState(0);
  const [phase, setPhase] = useState<'initialization' | 'execution' | 'synthesis' | 'completion'>('initialization');
  const [insights, setInsights] = useState<string[]>([]);

  const agentTypes = {
    researcher: { color: 'from-blue-500 to-blue-600', icon: '🔍', name: 'Researcher' },
    analyst: { color: 'from-green-500 to-green-600', icon: '📊', name: 'Analyst' },
    writer: { color: 'from-purple-500 to-purple-600', icon: '✍️', name: 'Writer' },
    validator: { color: 'from-orange-500 to-orange-600', icon: '✅', name: 'Validator' },
  };

  const sampleTasks = [
    'Analyzing market trends in AI industry',
    'Researching competitor strategies',
    'Evaluating user sentiment data',
    'Synthesizing research findings',
    'Generating executive summary',
    'Validating data accuracy',
    'Creating visual presentations',
    'Cross-referencing sources',
  ];

  const initializeSwarm = () => {
    const newAgents: Agent[] = [];
    const agentCount = 8;
    
    for (let i = 0; i < agentCount; i++) {
      const types = ['researcher', 'analyst', 'writer', 'validator'] as const;
      const type = types[i % types.length];
      
      newAgents.push({
        id: i,
        type,
        status: 'idle',
        task: sampleTasks[i],
        progress: 0,
        x: Math.random() * 300 + 50,
        y: Math.random() * 200 + 50,
        connections: [],
      });
    }
    
    setAgents(newAgents);
    setOverallProgress(0);
    setPhase('initialization');
    setInsights([]);
  };

  const startSwarm = () => {
    setIsRunning(true);
    setPhase('execution');
    
    // Simulate swarm execution
    const interval = setInterval(() => {
      setAgents(prev => prev.map(agent => {
        if (agent.status !== 'completed') {
          const newProgress = Math.min(agent.progress + Math.random() * 15, 100);
          const newStatus = newProgress >= 100 ? 'completed' : 
                           newProgress > 20 ? 'working' : 'idle';
          
          return { ...agent, progress: newProgress, status: newStatus };
        }
        return agent;
      }));
      
      setOverallProgress(prev => Math.min(prev + Math.random() * 5, 100));
    }, 500);

    // Add insights periodically
    const insightInterval = setInterval(() => {
      const newInsights = [
        '🔍 Market size: $15.7B with 23% YoY growth',
        '📊 Competitor analysis shows 3 key gaps',
        '✍️ Generated comprehensive market report',
        '✅ Validated all data sources and metrics',
        '🧠 Identified 5 strategic opportunities',
        '🎯 Recommended 3 immediate action items',
      ];
      
      setInsights(prev => {
        if (prev.length < newInsights.length) {
          return [...prev, newInsights[prev.length]];
        }
        return prev;
      });
    }, 2000);

    // Complete after 10 seconds
    setTimeout(() => {
      setIsRunning(false);
      setPhase('completion');
      setOverallProgress(100);
      clearInterval(interval);
      clearInterval(insightInterval);
    }, 10000);
  };

  const resetSwarm = () => {
    setIsRunning(false);
    initializeSwarm();
  };

  useEffect(() => {
    initializeSwarm();
  }, []);

  const getStatusIcon = (status: Agent['status']) => {
    switch (status) {
      case 'idle': return <Circle className="h-3 w-3 text-muted-foreground" />;
      case 'working': return <div className="h-3 w-3 rounded-full bg-yellow-500 animate-pulse" />;
      case 'completed': return <CheckCircle className="h-3 w-3 text-green-500" />;
      case 'collaborating': return <div className="h-3 w-3 rounded-full bg-blue-500 animate-ping" />;
      default: return <Circle className="h-3 w-3" />;
    }
  };

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Users className="h-6 w-6 mr-2 text-primary" />
            Agent Swarm Intelligence Demo
          </CardTitle>
          <Badge variant={isRunning ? 'default' : 'secondary'}>
            {isRunning ? 'Running' : 'Ready'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Control Panel */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center space-x-4">
            <Button
              onClick={isRunning ? () => setIsRunning(false) : startSwarm}
              disabled={phase === 'completion' && overallProgress >= 100}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {isRunning ? (
                <>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause Swarm
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Deploy Swarm
                </>
              )}
            </Button>
            <Button variant="outline" onClick={resetSwarm}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>
          
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Overall Progress</div>
            <div className="text-lg font-semibold">{Math.round(overallProgress)}%</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Swarm Performance</span>
            <span className="text-muted-foreground">{phase.charAt(0).toUpperCase() + phase.slice(1)}</span>
          </div>
          <Progress value={overallProgress} className="h-3" />
        </div>

        {/* Visualization Area */}
        <div className="relative bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg p-6 h-64 overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-dot-pattern bg-repeat"></div>
          </div>
          
          {/* Agents */}
          <div className="relative h-full">
            {agents.map((agent) => (
              <motion.div
                key={agent.id}
                className="absolute"
                style={{ left: agent.x, top: agent.y }}
                animate={{
                  scale: agent.status === 'working' ? [1, 1.1, 1] : 1,
                  rotate: agent.status === 'collaborating' ? 360 : 0,
                }}
                transition={{
                  scale: { duration: 1, repeat: agent.status === 'working' ? Infinity : 0 },
                  rotate: { duration: 2, repeat: agent.status === 'collaborating' ? Infinity : 0 },
                }}
              >
                <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${agentTypes[agent.type].color} flex items-center justify-center text-white font-semibold shadow-lg border-2 border-white`}>
                  <span className="text-lg">{agentTypes[agent.type].icon}</span>
                </div>
                
                {/* Status indicator */}
                <div className="absolute -top-1 -right-1">
                  {getStatusIcon(agent.status)}
                </div>
                
                {/* Progress ring for working agents */}
                {agent.status === 'working' && (
                  <div className="absolute inset-0 rounded-full border-2 border-yellow-400 animate-pulse">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 24 24">
                      <circle
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="2"
                        fill="none"
                        strokeDasharray={`${agent.progress * 0.628} 62.8`}
                        className="text-yellow-400"
                      />
                    </svg>
                  </div>
                )}
              </motion.div>
            ))}
            
            {/* Connection lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {agents.map((agent, i) => 
                agents.slice(i + 1).map((otherAgent, j) => {
                  if (agent.status === 'working' && otherAgent.status === 'working') {
                    return (
                      <motion.line
                        key={`${i}-${j}`}
                        x1={agent.x + 24}
                        y1={agent.y + 24}
                        x2={otherAgent.x + 24}
                        y2={otherAgent.y + 24}
                        stroke="url(#gradient)"
                        strokeWidth="2"
                        strokeDasharray="5,5"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={{ pathLength: 1, opacity: 0.6 }}
                        transition={{ duration: 0.5 }}
                      />
                    );
                  }
                  return null;
                })
              )}
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3B82F6" />
                  <stop offset="100%" stopColor="#8B5CF6" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>

        {/* Agent Status Panel */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(agentTypes).map(([type, config]) => {
            const typeAgents = agents.filter(a => a.type === type);
            const activeCount = typeAgents.filter(a => a.status === 'working' || a.status === 'completed').length;
            
            return (
              <div key={type} className="text-center p-3 bg-muted/30 rounded-lg">
                <div className={`w-8 h-8 mx-auto mb-2 rounded-full bg-gradient-to-r ${config.color} flex items-center justify-center text-white text-sm`}>
                  {config.icon}
                </div>
                <div className="text-sm font-medium">{config.name}</div>
                <div className="text-xs text-muted-foreground">
                  {activeCount}/{typeAgents.length} active
                </div>
              </div>
            );
          })}
        </div>

        {/* Real-time Insights */}
        <AnimatePresence>
          {insights.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-2"
            >
              <h4 className="text-sm font-medium flex items-center">
                <Brain className="h-4 w-4 mr-2" />
                Real-time Insights
              </h4>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {insights.map((insight, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="text-sm p-2 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded border-l-2 border-primary"
                  >
                    {insight}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Performance Metrics */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">{agents.filter(a => a.status === 'working').length}</div>
            <div className="text-xs text-muted-foreground">Active Agents</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{agents.filter(a => a.status === 'completed').length}</div>
            <div className="text-xs text-muted-foreground">Completed Tasks</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{insights.length}</div>
            <div className="text-xs text-muted-foreground">Insights Generated</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AgentSwarmDemo;
